<?php
/**
 * Plugin Name: WP Health Monitor
 * Description: Monitoring für Core, Plugins, Themes
 * Version:                 1.3.7
 * Author:      ProjectPartner Kleeschulte GmbH
 * License:     GPLv2 or later
 */

if (!defined('ABSPATH')) { exit; }

define('WHM_VERSION', '1.3.7');
define('WHM_HOOK_FIXED', 'whm_scan_at_time'); // receives int minute-of-day (0..1410 step 30)
define('WHM_OPTION_LAST_RUN', 'whm_last_run');
define('WHM_OPTION_LAST_DATA', 'whm_last_data');
define('WHM_OPTION_TIME1', 'whm_time1'); // string HH:MM
define('WHM_OPTION_TIME2', 'whm_time2'); 
define('WHM_BUILD', '2025-10-18'); // Datestamp (YYYY-MM-DD)
define('WHM_UPDATE_BASE', 'https://webdivision.io/download/module/WHM/live'); // Base URL for updates

// New options for maintenance meta
define('WHM_OPTION_LAST_UPDATED_BY', 'whm_last_updated_by'); // string
define('WHM_OPTION_LAST_UPDATED_DATE', 'whm_last_updated_date'); // YYYY-MM-DD
define('WHM_OPTION_NOTES', 'whm_notes'); // textarea
// string HH:MM

register_activation_hook(__FILE__, 'whm_on_activate');
register_deactivation_hook(__FILE__, 'whm_on_deactivate');

add_action('admin_menu', 'whm_register_admin_page');
add_action('admin_post_whm_scan', 'whm_handle_manual_scan');
add_action('admin_post_whm_save_settings', 'whm_handle_save_settings');
// Updater & refresh hooks

add_filter('plugin_row_meta', 'whm_plugin_row_meta', 10, 2);
add_action('load-update-core.php', 'whm_update_force_refresh_on_check_again');
add_action('load-plugins.php', 'whm_update_force_refresh_on_check_again');
add_action('admin_post_whm_check_updates_now', 'whm_handle_check_updates_now');
add_action('admin_post_whm_self_update', 'whm_handle_self_update');
add_action('admin_notices', 'whm_self_update_admin_notices');

add_action(WHM_HOOK_FIXED, 'whm_run_scheduled_scan', 10, 1);

/** Activation */
function whm_on_activate() {
    // Migration cleanup: unschedule legacy variants
    foreach (['whm_run_scan_event','whm_run_scan_6','whm_run_scan_18'] as $legacy) {
        $ts = wp_next_scheduled($legacy);
        if ($ts) wp_unschedule_event($ts, $legacy);
    }
    // Unschedule fixed-hour args from older versions
    foreach ([[6],[18],['06:00'],['18:00']] as $args) {
        $e = wp_get_scheduled_event(WHM_HOOK_FIXED, $args);
        if ($e) wp_unschedule_event($e->timestamp, WHM_HOOK_FIXED, $args);
    }
    // Defaults for times
    if (!get_option(WHM_OPTION_TIME1)) update_option(WHM_OPTION_TIME1, '06:00', false);
    if (!get_option(WHM_OPTION_TIME2)) update_option(WHM_OPTION_TIME2, '18:00', false);
    // Schedule
    whm_ensure_schedules();
}

/** Deactivation */
function whm_on_deactivate() {
    // Unschedule any known 30-min slots (safe: iterate 0..1410 by 30)
    for ($m=0; $m<24*60; $m+=30) {
        $e = wp_get_scheduled_event(WHM_HOOK_FIXED, [$m]);
        if ($e) wp_unschedule_event($e->timestamp, WHM_HOOK_FIXED, [$m]);
    }
}

/** Ensure schedules exist on init */
add_action('init', function () {
    whm_ensure_schedules();
});

/** Admin menu */
function whm_register_admin_page() {
    add_menu_page('WP Health Monitor','WP Health Monitor','manage_options','whm','whm_render_admin_page','dashicons-heart',80);
}

/** Render admin page */
function whm_render_admin_page() {
    if (!current_user_can('manage_options')) return;
    $last = get_option(WHM_OPTION_LAST_RUN);
    $data = get_option(WHM_OPTION_LAST_DATA);
    $t1 = get_option(WHM_OPTION_TIME1, '06:00');
    $t2 = get_option(WHM_OPTION_TIME2, '18:00');
    $last_by   = get_option(WHM_OPTION_LAST_UPDATED_BY, '');
    $last_date = get_option(WHM_OPTION_LAST_UPDATED_DATE, '');
    $notes     = get_option(WHM_OPTION_NOTES, '');

    $m1 = whm_time_to_minutes($t1);
    $m2 = whm_time_to_minutes($t2);

    $e1 = ($m1 !== null) ? wp_get_scheduled_event(WHM_HOOK_FIXED, [$m1]) : null;
    $e2 = ($m2 !== null) ? wp_get_scheduled_event(WHM_HOOK_FIXED, [$m2]) : null;

    $upload   = wp_upload_dir();
    $json_dir = trailingslashit($upload['basedir']).'wp-health-monitor/';
    $json_path= $json_dir.'status.json';
    $json_url = trailingslashit($upload['baseurl']).'wp-health-monitor/status.json';

    $perm_str = 'n/a';
    if (file_exists($json_path)) {
        $perm_str = substr(sprintf('%o', fileperms($json_path)), -4);
    }

    // wp-cron state hints
    $cron_disabled = (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON);
    $alt_cron = (defined('ALTERNATE_WP_CRON') && ALTERNATE_WP_CRON);

    // Build dropdown options (00:00..23:30)
    $opts = '';
    for ($h=0; $h<24; $h++) {
        foreach ([0,30] as $mm) {
            $label = sprintf('%02d:%02d', $h, $mm);
            $opts .= '<option value="'.$label.'">'.$label.'</option>';
        }
    }

    $theme_rows = '';
    if (is_array($data) && isset($data['themes']['list']) && is_array($data['themes']['list'])) {
        foreach ($data['themes']['list'] as $t) {
            $flags = [];
            if (!empty($t['is_active'])) $flags[] = 'aktiv';
            if (!empty($t['is_parent_of_active'])) $flags[] = 'Parent';
            if (!empty($t['is_child'])) $flags[] = 'Child';
            $flag_str = $flags ? ' ('.implode(', ', $flags).')' : '';
            $update_str = !empty($t['needs_update']) ? ('Update → '.$t['new_version']) : '–';
            $theme_rows .= '<tr><td>'.esc_html($t['name']).$flag_str.'</td><td>'.esc_html($t['version']).'</td><td>'.esc_html($t['stylesheet']).'</td><td>'.esc_html($update_str).'</td></tr>';
        }
    }
    ?>
    <div class="wrap">
        <h1>WP Health Monitor <small style="font-size:12px;opacity:.7;">v<?php echo esc_html(WHM_VERSION); ?></small></h1>
        <div style="margin:6px 0 14px; font-size:12px; opacity:.8;">
            WEBDIVISION by ProjectPartner Kleeschulte GmbH | All Rights Reserved
        </div>

        <?php if ($cron_disabled): ?>
            <div class="notice notice-warning"><p><strong>Hinweis:</strong> <code>DISABLE_WP_CRON</code> ist aktiviert. Geplante Scans laufen nur, wenn ein externer Server-Cron <code>wp-cron.php</code> triggert.</p></div>
        <?php endif; ?>
        <?php if ($alt_cron): ?>
            <div class="notice notice-info"><p><strong>Hinweis:</strong> <code>ALTERNATE_WP_CRON</code> ist aktiv.</p></div>
        <?php endif; ?>

        <p>Letzter Scan: <strong><?php echo $last ? esc_html(date_i18n(get_option('date_format').' '.get_option('time_format'), $last)) : '–'; ?></strong></p>
        <p>Nächste Scans:
            <?php
            echo '<strong>'.esc_html($t1).'</strong> → '.($e1 ? esc_html(date_i18n(get_option('date_format'))) : 'wird geplant…');
            echo ' &nbsp; | &nbsp; ';
            echo '<strong>'.esc_html($t2).'</strong> → '.($e2 ? esc_html(date_i18n(get_option('date_format'))) : 'wird geplant…');
            ?>
        </p>
        <?php if (!empty($last_by) || !empty($last_date)): ?>
            <p>Zuletzt gewartet<?php echo !empty($last_by) ? ' von <strong>'.esc_html($last_by).'</strong>' : ''; ?><?php echo !empty($last_date) ? ' am <strong>'.esc_html($last_date).'</strong>' : ''; ?>.</p>
        <?php endif; ?>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"  style="margin: 12px 0 20px;">
            <?php wp_nonce_field('whm_save_settings','whm_settings_nonce'); ?>
            <input type="hidden" name="action" value="whm_save_settings">
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">Scan-Zeit 1</th>
                    <td>
                        <select name="whm_time1" required>
                            <?php echo str_replace('value="'.esc_attr($t1).'"', 'value="'.esc_attr($t1).'" selected', $opts); ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Scan-Zeit 2</th>
                    <td>
                        <select name="whm_time2" required>
                            <?php echo str_replace('value="'.esc_attr($t2).'"', 'value="'.esc_attr($t2).'" selected', $opts); ?>
                        </select>
                    </td>
                </tr>
            
                <tr>
                    <th scope="row">Letztes Update durchgeführt von</th>
                    <td>
                        <input type="text" name="whm_last_updated_by" value="<?php echo esc_attr($last_by); ?>" class="regular-text" placeholder="Name des Mitarbeiters">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Datum der letzten Wartung</th>
                    <td>
                        <input type="date" name="whm_last_updated_date" value="<?php echo esc_attr($last_date); ?>">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Bemerkungen</th>
                    <td>
                        <textarea name="whm_notes" rows="5" class="large-text" placeholder="Interne Notizen…"><?php echo esc_textarea($notes); ?></textarea>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Updates</th>
                    <td>
                        <a class="button" href="<?php echo wp_nonce_url( admin_url('admin-post.php?action=whm_check_updates_now'), 'whm_check_updates_now' ); ?>">Update jetzt prüfen</a>
                        <a class="button button-primary" href="<?php echo wp_nonce_url( admin_url('admin-post.php?action=whm_self_update'), 'whm_self_update' ); ?>">Jetzt aktualisieren</a>
                    </td>
                </tr></table>
            <p class="submit"><button class="button button-primary">Einstellungen speichern</button></p>
        </form>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:1em;">
            <?php wp_nonce_field('whm_scan_now','whm_nonce'); ?>
            <input type="hidden" name="action" value="whm_scan">
            <button class="button">Jetzt scannen</button>
        </form>

        <h2>Status</h2>
        <?php if (is_array($data)): ?>
            <table class="widefat striped"><tbody>
                <tr><th>WP-Version</th><td><?php echo esc_html($data['wordpress']['version']); ?></td></tr>
                <tr><th>PHP</th><td><?php echo esc_html($data['environment']['php_version']); ?></td></tr>
                <tr><th>MySQL</th><td><?php echo esc_html($data['environment']['mysql_version']); ?></td></tr>
                <tr><th>Plugins (gesamt / Updates)</th><td><?php echo esc_html($data['plugins']['total'].' / '.$data['plugins']['updates_available']); ?></td></tr>
                <tr><th>Themes (gesamt / Updates)</th><td><?php echo esc_html($data['themes']['installed_total'].' / '.$data['themes']['updates_available']); ?></td></tr>
                <tr><th>Aktives Theme</th><td><?php echo esc_html($data['themes']['active']['name'].' '.$data['themes']['active']['version']); ?></td></tr>
                <?php if (!empty($data['themes']['parent'])): ?>
                <tr><th>Parent-Theme</th><td><?php echo esc_html($data['themes']['parent']['name'].' '.$data['themes']['parent']['version']); ?></td></tr>
                <?php endif; ?>
                <tr><th>Core-Update?</th><td><?php echo !empty($data['updates']['core_update_available']) ? 'Ja' : 'Nein'; ?></td></tr>
                <tr><th>SSL aktiv / Zertifikat OK</th><td><?php echo ($data['ssl']['https'] ? 'Ja' : 'Nein').' / '.(is_null($data['ssl']['certificate_ok'])?'n/a':($data['ssl']['certificate_ok']?'Ja':'Nein')); ?></td></tr>
                <tr><th>Startseiten-Status / Zeit</th><td><?php echo esc_html(($data['http_check']['status_code']??'n/a').' / '.($data['http_check']['duration_ms']??'n/a').' ms'); ?></td></tr>
                <tr><th>Load Average</th><td><?php echo esc_html($data['environment']['load_average']); ?></td></tr>
            </tbody></table>

            <h3 style="margin-top:1em;">Installierte Themes</h3>
            <table class="widefat striped">
                <thead><tr><th>Name</th><th>Version</th><th>Stylesheet</th><th>Update</th></tr></thead>
                <tbody><?php echo $theme_rows ?: '<tr><td colspan="4">Keine Daten.</td></tr>'; ?></tbody>
            </table>

            <?php if (isset($data['themes']['avada'])): 
                $av = $data['themes']['avada']; ?>
                <h3 style="margin-top:1em;">Avada-Erkennung</h3>
                <table class="widefat striped"><tbody>
                    <tr><th>Gefunden</th><td><?php echo !empty($av['detected']) ? 'Ja' : 'Nein'; ?></td></tr>
                    <tr><th>Aktives Theme ist Child</th><td><?php echo !empty($av['active_is_child']) ? 'Ja' : 'Nein'; ?></td></tr>
                    <tr><th>Parent-Update?</th><td><?php echo !empty($av['parent_update_available']) ? 'Ja' : 'Nein'; ?></td></tr>
                    <?php if (!empty($av['parent_stylesheet'])): ?>
                    <tr><th>Parent Stylesheet</th><td><?php echo esc_html($av['parent_stylesheet']); ?></td></tr>
                    <?php endif; ?>
                </tbody></table>
            <?php endif; ?>

            <p style="margin-top:1em;">
                <a class="button" href="<?php echo esc_url($json_url); ?>" target="_blank" rel="noreferrer">status.json ansehen</a>
                <span style="margin-left:10px;opacity:.7;">Pfad: <?php echo esc_html($json_path); ?> · Rechte: <?php echo esc_html($perm_str); ?></span>
            </p>
            <h2>Rohdaten</h2>
            <pre style="max-height:400px;overflow:auto;background:#fff;border:1px solid #ccd0d4;padding:10px;"><?php echo esc_html(json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)); ?></pre>
        <?php else: ?>
            <p>Noch keine Daten.</p>
        <?php endif; ?>
    </div>
    <?php
}

/** Handle manual scan */
function whm_handle_manual_scan() {
    if (!current_user_can('manage_options') || !check_admin_referer('whm_scan_now','whm_nonce')){ wp_die('Nicht erlaubt.'); }
    whm_run_scan();
    wp_safe_redirect(admin_url('admin.php?page=whm&scanned=1')); exit;
}

/** Handle settings save */
function whm_handle_save_settings() {
    if (!current_user_can('manage_options') || !check_admin_referer('whm_save_settings','whm_settings_nonce')){ wp_die('Nicht erlaubt.'); }

    $t1 = isset($_POST['whm_time1']) ? sanitize_text_field($_POST['whm_time1']) : '06:00';
    $t2 = isset($_POST['whm_time2']) ? sanitize_text_field($_POST['whm_time2']) : '18:00';

    // validate 30-min step HH:MM
    foreach (['t1'=>$t1,'t2'=>$t2] as $k=>$v) {
        if (!preg_match('/^(?:[01]\d|2[0-3]):(?:00|30)$/', $v)) {
            if ($k==='t1') $t1 = '06:00'; else $t2 = '18:00';
        }
    }

    update_option(WHM_OPTION_TIME1, $t1, false);
    update_option(WHM_OPTION_TIME2, $t2, false);

    
    // Save maintenance meta
    $by   = isset($_POST['whm_last_updated_by']) ? sanitize_text_field($_POST['whm_last_updated_by']) : '';
    $d    = isset($_POST['whm_last_updated_date']) ? sanitize_text_field($_POST['whm_last_updated_date']) : '';
    $note = isset($_POST['whm_notes']) ? sanitize_textarea_field($_POST['whm_notes']) : '';

    update_option(WHM_OPTION_LAST_UPDATED_BY, $by, false);
    update_option(WHM_OPTION_LAST_UPDATED_DATE, $d, false);
    update_option(WHM_OPTION_NOTES, $note, false);
// Reschedule
    whm_reschedule_all();

    wp_safe_redirect(admin_url('admin.php?page=whm&updated=1')); exit;
}

/** Ensure current schedules exist for saved times */
function whm_ensure_schedules() {
    $t1 = get_option(WHM_OPTION_TIME1, '06:00');
    $t2 = get_option(WHM_OPTION_TIME2, '18:00');
    $last_by   = get_option(WHM_OPTION_LAST_UPDATED_BY, '');
    $last_date = get_option(WHM_OPTION_LAST_UPDATED_DATE, '');
    $notes     = get_option(WHM_OPTION_NOTES, '');
    $m1 = whm_time_to_minutes($t1);
    $m2 = whm_time_to_minutes($t2);

    if ($m1 !== null && !wp_get_scheduled_event(WHM_HOOK_FIXED, [$m1])) {
        whm_schedule_next_at_minute($m1);
    }
    if ($m2 !== null && !wp_get_scheduled_event(WHM_HOOK_FIXED, [$m2])) {
        whm_schedule_next_at_minute($m2);
    }
}

/** Reschedule after settings change */
function whm_reschedule_all() {
    // Clear all existing WHM events (iterate known minute slots)
    for ($m=0; $m<24*60; $m+=30) {
        $e = wp_get_scheduled_event(WHM_HOOK_FIXED, [$m]);
        if ($e) wp_unschedule_event($e->timestamp, WHM_HOOK_FIXED, [$m]);
    }
    // Also clear legacy [6]/[18]
    foreach ([[6],[18],['06:00'],['18:00']] as $args) {
        $e = wp_get_scheduled_event(WHM_HOOK_FIXED, $args);
        if ($e) wp_unschedule_event($e->timestamp, WHM_HOOK_FIXED, $args);
    }
    // Schedule for new times
    whm_ensure_schedules();
}

/** Scheduled callback: receives minute-of-day INT */
function whm_run_scheduled_scan($minute_of_day = null) {
    $minute_of_day = is_null($minute_of_day) ? null : (int)$minute_of_day;
    whm_run_scan();
    if (!is_null($minute_of_day)) {
        whm_schedule_next_at_minute($minute_of_day);
    }
}

/** Schedule single event for next occurrence of given minute-of-day (0..1410) */
function whm_schedule_next_at_minute($minute_of_day) {
    $minute_of_day = (int)$minute_of_day;
    if ($minute_of_day < 0 || $minute_of_day >= 24*60 || ($minute_of_day % 30) !== 0) return;

    $h = intdiv($minute_of_day, 60);
    $m = $minute_of_day % 60;

    $tz  = wp_timezone();
    $now = new DateTimeImmutable('now', $tz);
    $next = $now->setTime($h, $m, 0);
    if ($next <= $now) {
        $next = $next->modify('+1 day');
    }
    $ts_utc = (int)$next->setTimezone(new DateTimeZone('UTC'))->format('U');

    if ($existing = wp_get_scheduled_event(WHM_HOOK_FIXED, [$minute_of_day])) {
        wp_unschedule_event($existing->timestamp, WHM_HOOK_FIXED, [$minute_of_day]);
    }
    wp_schedule_single_event($ts_utc, WHM_HOOK_FIXED, [$minute_of_day]);
}

/** Convert "HH:MM" (00|30) to minutes-of-day */
function whm_time_to_minutes($time_str) {
    if (!is_string($time_str) || !preg_match('/^(?:[01]\d|2[0-3]):(?:00|30)$/', $time_str)) return null;
    list($h,$m) = explode(':', $time_str);
    return ((int)$h)*60 + ((int)$m);
}

/** Shared scan */
function whm_run_scan() {
    $data = whm_collect_data();
    whm_write_json($data);
    update_option(WHM_OPTION_LAST_DATA, $data, false);
    update_option(WHM_OPTION_LAST_RUN, current_time('timestamp'));
}

/** Data collection (plugins, themes incl. Avada, env, HTTP/SSL) */
function whm_collect_data(): array {
    global $wpdb;

    // Core
    $core_version = get_bloginfo('version');

    // Plugins & updates
    if (!function_exists('get_plugins')) require_once ABSPATH.'wp-admin/includes/plugin.php';
    if (!function_exists('wp_update_plugins')) require_once ABSPATH.'wp-includes/update.php';
    if (function_exists('wp_update_plugins')) @wp_update_plugins();

    $all_plugins   = function_exists('get_plugins') ? get_plugins() : [];
    $plugins_total = is_array($all_plugins) ? count($all_plugins) : 0;
    $updates_obj_p = get_site_transient('update_plugins');
    $updates_res_p = (is_object($updates_obj_p) && isset($updates_obj_p->response)) ? $updates_obj_p->response : [];
    if (is_object($updates_res_p)) $updates_res_p = (array)$updates_res_p;
    if (!is_array($updates_res_p)) $updates_res_p = [];

    $plugins_updates = 0;
    $plugins_list = [];
    foreach ($all_plugins as $file => $p) {
        $needs = isset($updates_res_p[$file]);
        if ($needs) $plugins_updates++;
        $plugins_list[] = [
            'name' => $p['Name'] ?? '',
            'version' => $p['Version'] ?? '',
            'file' => $file,
            'needs_update' => $needs,
            'new_version' => $needs ? ($updates_res_p[$file]->new_version ?? '') : '',
        ];
    }

    // Themes & updates
    if (!function_exists('get_core_updates')) require_once ABSPATH.'wp-admin/includes/update.php';
    if (function_exists('wp_update_themes')) @wp_update_themes();
    $updates_obj_t = get_site_transient('update_themes');
    $updates_res_t = (is_object($updates_obj_t) && isset($updates_obj_t->response)) ? $updates_obj_t->response : [];
    if (is_object($updates_res_t)) $updates_res_t = (array)$updates_res_t;
    if (!is_array($updates_res_t)) $updates_res_t = [];

    $active_theme = wp_get_theme();
    $parent_theme = $active_theme->parent();
    $installed_themes = function_exists('wp_get_themes') ? wp_get_themes() : [];
    $installed_total = is_array($installed_themes) ? count($installed_themes) : 0;
    $themes_updates = 0;
    $themes_list = [];

    foreach ($installed_themes as $stylesheet => $t) {
        $is_active = ($active_theme && $stylesheet === $active_theme->get_stylesheet());
        $is_parent_of_active = ($parent_theme && $stylesheet === $parent_theme->get_stylesheet());
        $needs_update = isset($updates_res_t[$stylesheet]);
        if ($needs_update) $themes_updates++;
        $themes_list[] = [
            'name' => $t->get('Name'),
            'version' => $t->get('Version'),
            'stylesheet' => $t->get_stylesheet(),
            'template' => $t->get_template(),
            'is_active' => $is_active,
            'is_parent_of_active' => $is_parent_of_active,
            'is_child' => $is_active ? (bool)$parent_theme : false,
            'needs_update' => $needs_update,
            'new_version' => $needs_update ? ($updates_res_t[$stylesheet]['new_version'] ?? ($updates_res_t[$stylesheet]->new_version ?? '')) : '',
        ];
    }

    // Avada detection
    $avada = [
        'detected' => false,
        'active_is_child' => (bool)$parent_theme,
        'parent_update_available' => false,
        'parent_stylesheet' => '',
    ];
    foreach ($installed_themes as $stylesheet => $t) {
        $n = strtolower($t->get('Name'));
        $tpl = strtolower($t->get_template());
        $ss  = strtolower($t->get_stylesheet());
        if ($n === 'avada' || $tpl === 'avada' || $ss === 'avada') {
            $avada['detected'] = true;
            if ($parent_theme && $parent_theme->get_stylesheet() === $stylesheet) {
                $avada['parent_stylesheet'] = $stylesheet;
                $avada['parent_update_available'] = isset($updates_res_t[$stylesheet]);
            }
        }
    }

    // Core updates
    $core_updates = function_exists('get_core_updates') ? get_core_updates() : [];
    $core_upd_available = false;
    if (is_array($core_updates)) {
        foreach ($core_updates as $u) {
            if (!empty($u->response) && $u->response !== 'latest') { $core_upd_available = true; break; }
        }
    }

    // HTTP / SSL
    $http = whm_check_homepage();

    // Environment
    $load = function_exists('sys_getloadavg') ? @sys_getloadavg() : false;
    $load_str = 'n/a';
    if (is_array($load)) {
        $load_str = implode(', ', array_map('strval', $load));
    }
    $env = [
        'php_version'   => PHP_VERSION,
        'mysql_version' => method_exists($wpdb,'db_version') ? $wpdb->db_version() : '',
        'server'        => $_SERVER['SERVER_SOFTWARE'] ?? php_sapi_name(),
        'os'            => defined('PHP_OS_FAMILY') ? PHP_OS_FAMILY : PHP_OS,
        'load_average'  => $load_str,
    ];

    return [
        'generated_at' => current_time('mysql'),
        'site' => [ 'home_url' => home_url('/') ],
        'wordpress' => ['version' => $core_version],
        'plugins'   => ['total' => $plugins_total, 'updates_available' => $plugins_updates, 'list' => $plugins_list],
        'themes'    => [
            'installed_total' => $installed_total,
            'updates_available' => $themes_updates,
            'active' => [
                'name' => $active_theme->get('Name'),
                'version' => $active_theme->get('Version'),
                'stylesheet' => $active_theme->get_stylesheet(),
                'template' => $active_theme->get_template(),
                'is_child' => (bool)$parent_theme,
                'update_available' => isset($updates_res_t[$active_theme->get_stylesheet()]),
                'new_version' => isset($updates_res_t[$active_theme->get_stylesheet()]) ? ($updates_res_t[$active_theme->get_stylesheet()]['new_version'] ?? ($updates_res_t[$active_theme->get_stylesheet()]->new_version ?? '')) : '',
            ],
            'parent' => $parent_theme ? [
                'name' => $parent_theme->get('Name'),
                'version' => $parent_theme->get('Version'),
                'stylesheet' => $parent_theme->get_stylesheet(),
                'template' => $parent_theme->get_template(),
                'update_available' => isset($updates_res_t[$parent_theme->get_stylesheet()]),
                'new_version' => isset($updates_res_t[$parent_theme->get_stylesheet()]) ? ($updates_res_t[$parent_theme->get_stylesheet()]['new_version'] ?? ($updates_res_t[$parent_theme->get_stylesheet()]->new_version ?? '')) : '',
            ] : null,
            'list'   => $themes_list,
            'avada'  => $avada,
        ],
        'updates'   => ['core_update_available' => $core_upd_available],
        'ssl'       => ['https' => $http['https'], 'certificate_ok' => $http['ssl_ok']],
        'http_check'=> $http,
        'environment' => $env,
    ];
}

/** HEAD check with cURL fallback */
function whm_check_homepage(): array {
    $url = home_url('/');
    $https = parse_url($url, PHP_URL_SCHEME) === 'https';
    $duration_ms = $status_code = null;
    $ssl_ok = null;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_NOBODY         => true,
            CURLOPT_HEADER         => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'WHM/'.WHM_VERSION,
        ]);
        $start = microtime(true);
        curl_exec($ch);
        $duration_ms = (int) round((microtime(true) - $start) * 1000);
        $status_code = curl_getinfo($ch, defined('CURLINFO_RESPONSE_CODE') ? CURLINFO_RESPONSE_CODE : CURLINFO_HTTP_CODE);
        $verify_res  = curl_getinfo($ch, CURLINFO_SSL_VERIFYRESULT);
        $ssl_ok = $https ? ($verify_res === 0) : null;
        curl_close($ch);
    } else {
        $args = ['method' => 'HEAD', 'timeout' => 15, 'sslverify' => true, 'user-agent' => 'WHM/'.WHM_VERSION];
        $start = microtime(true);
        $res = wp_remote_request($url, $args);
        $duration_ms = (int) round((microtime(true) - $start) * 1000);
        if (is_wp_error($res)) {
            $status_code = null;
        } else {
            $status_code = wp_remote_retrieve_response_code($res);
        }
        $ssl_ok = null;
    }
    return ['url'=>$url,'status_code'=>$status_code,'duration_ms'=>$duration_ms,'https'=>$https,'ssl_ok'=>$ssl_ok];
}

/** Write JSON with enforced permissions */
function whm_write_json(array $data): void {
    $upload = wp_upload_dir();
    $dir = trailingslashit($upload['basedir']).'wp-health-monitor';
    $dir_mode  = apply_filters('whm_dir_mode',  defined('FS_CHMOD_DIR')  ? FS_CHMOD_DIR  : 0755);
    $file_mode = apply_filters('whm_file_mode', defined('FS_CHMOD_FILE') ? FS_CHMOD_FILE : 0644);

    if (!file_exists($dir)) {
        wp_mkdir_p($dir);
        @chmod($dir, $dir_mode);
    } else {
        @chmod($dir, $dir_mode);
    }

    $index = trailingslashit($dir).'index.php';
    if (!file_exists($index)) {
        @file_put_contents($index, "<?php // Silence is golden.\n");
    }
    @chmod($index, $file_mode);

    $file = trailingslashit($dir).'status.json';
    @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
    @chmod($file, $file_mode);
}

/** WP-CLI */
if (defined('WP_CLI') && WP_CLI) {
    class WHM_CLI extends \WP_CLI_Command {
        public function scan() {
            $data = whm_collect_data();
            whm_write_json($data);
            \WP_CLI::success('Scan abgeschlossen. JSON geschrieben.');
        }
    }
    \WP_CLI::add_command('whm', 'WHM_CLI');
}


/** =============================
 *  Updater (JSON/TXT + Folder Scan)
 *  ============================= */
if (!function_exists('whm_parse_latest_from_listing')) {
    function deprecated_whm_parse_latest_from_listing($html, $base) {
        if (empty($html)) return null;
        $found = array();
        if (preg_match_all('/wp-health-monitor-([0-9]+\.[0-9]+\.[0-9]+)\.zip/i', $html, $m)) {
            foreach ($m[1] as $v) { $found[] = $v; }
        }
        if (empty($found)) return null;
        usort($found, 'version_compare');
        $latest_v = end($found);
        $file = 'wp-health-monitor-'.$latest_v.'.zip';
        return array(
            'new_version' => $latest_v,
            'package'     => trailingslashit($base).$file,
            'url'         => trailingslashit($base),
            'last_updated'=> '',
            'requires'    => '5.6',
            'tested'      => get_bloginfo('version'),
            'requires_php'=> '7.4',
            'sections'    => array('description'=>'WP Health Monitor', 'changelog'=>''),
            'build'       => ''
        );
    }
}

if (!function_exists('whm_get_update_metadata')) {
    function deprecated_whm_get_update_metadata($force = false) {
        $cache_key = 'whm_update_meta_cache';
        if (!$force) {
            $cached = get_site_transient($cache_key);
            if ($cached && is_array($cached)) return $cached;
        }
        $base = WHM_UPDATE_BASE;
        $endpoints = array(
            trailingslashit($base).'update.json',
            trailingslashit($base).'metadata.json',
            trailingslashit($base).'version.json',
            trailingslashit($base).'version.txt',
        );
        $meta = null;

        // Preferred: JSON/TXT
        foreach ($endpoints as $url) {
            $res = wp_remote_get($url, array('timeout' => 10, 'sslverify' => true));
            if (is_wp_error($res)) continue;
            if (wp_remote_retrieve_response_code($res) !== 200) continue;
            $body = wp_remote_retrieve_body($res);
            if (preg_match('/\.txt$/', $url)) {
                $lines = preg_split('/\r?\n/', trim($body));
                if (!empty($lines[0])) {
                    $meta = array(
                        'new_version' => trim($lines[0]),
                        'package'     => !empty($lines[1]) ? trim($lines[1]) : trailingslashit($base).'wp-health-monitor.zip',
                        'url'         => trailingslashit($base),
                        'last_updated'=> !empty($lines[2]) ? trim($lines[2]) : '',
                        'requires'    => '5.6',
                        'tested'      => get_bloginfo('version'),
                        'requires_php'=> '7.4',
                        'sections'    => array('changelog'=>'(Kein Changelog verfügbar)'),
                        'build'       => !empty($lines[3]) ? trim($lines[3]) : ''
                    );
                }
            } else {
                $json = json_decode($body, true);
                if (is_array($json) && !empty($json['new_version'])) {
                    $meta = $json;
                }
            }
            if ($meta) break;
        }

        // Fallback: directory listing
        if (!$meta) {
            $res = wp_remote_get(trailingslashit($base), array('timeout' => 10, 'sslverify' => true));
            if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
                $html = wp_remote_retrieve_body($res);
                $meta = whm_parse_latest_from_listing($html, $base);
            }
        }
        if (!$meta) return null;

        $meta = wp_parse_args($meta, array(
            'new_version' => '',
            'package'     => '',
            'url'         => trailingslashit($base),
            'last_updated'=> '',
            'requires'    => '5.6',
            'tested'      => get_bloginfo('version'),
            'requires_php'=> '7.4',
            'sections'    => array('description' => 'WP Health Monitor', 'changelog' => ''),
            'build'       => ''
        ));
        set_site_transient($cache_key, $meta, MINUTE_IN_SECONDS * 2);
        return $meta;
    }
}

if (!function_exists('whm_check_for_plugin_update')) {
    function deprecated_whm_check_for_plugin_update($transient) {
        if (empty($transient) || !is_object($transient)) return $transient;
        $meta = whm_get_update_metadata(false);
        if (!$meta || empty($meta['new_version'])) return $transient;

        $installed_version = WHM_VERSION;
        $needs_update = version_compare($meta['new_version'], $installed_version, '>');

        if (!$needs_update && !empty($meta['build'])) {
            $needs_update = (defined('WHM_BUILD') && WHM_BUILD !== $meta['build']);
        }

        $plugin_file = plugin_basename(__FILE__);
        if ($needs_update) {
            $obj = new stdClass();
            $obj->slug        = 'wp-health-monitor';
            $obj->plugin      = $plugin_file;
            $obj->new_version = $meta['new_version'];
            $obj->url         = !empty($meta['url']) ? $meta['url'] : trailingslashit(WHM_UPDATE_BASE);
            $obj->package     = $meta['package'];
            $transient->response[$plugin_file] = $obj;
        } else {
            $obj = new stdClass();
            $obj->slug        = 'wp-health-monitor';
            $obj->plugin      = $plugin_file;
            $obj->new_version = $installed_version;
            $obj->url         = trailingslashit(WHM_UPDATE_BASE);
            $obj->package     = '';
            $transient->no_update[$plugin_file] = $obj;
        }
        return $transient;
    }
}

if (!function_exists('whm_plugins_api_handler')) {
    function deprecated_whm_plugins_api_handler($res, $action, $args) {
        if ($action !== 'plugin_information') return $res;
        if (!isset($args->slug) || $args->slug !== 'wp-health-monitor') return $res;
        $meta = whm_get_update_metadata(false);
        if (!$meta) return $res;
        $info = new stdClass();
        $info->name          = 'WP Health Monitor';
        $info->slug          = 'wp-health-monitor';
        $info->version       = $meta['new_version'];
        $info->author        = '<a href="https://webdivision.io" target="_blank" rel="noreferrer">ProjectPartner Kleeschulte GmbH</a>';
        $info->homepage      = !empty($meta['url']) ? $meta['url'] : trailingslashit(WHM_UPDATE_BASE);
        $info->download_link = $meta['package'];
        $info->requires      = $meta['requires'];
        $info->tested        = $meta['tested'];
        $info->requires_php  = $meta['requires_php'];
        $info->last_updated  = $meta['last_updated'];
        $info->sections      = $meta['sections'];
        return $info;
    }
}

if (!function_exists('whm_plugin_row_meta')) {
    function whm_plugin_row_meta($links, $file) {
        if ($file === plugin_basename(__FILE__)) {
            $label = 'v'.WHM_VERSION;
            if (defined('WHM_BUILD') && WHM_BUILD) {
                $label .= ' · Build '.WHM_BUILD;
            }
            $links[] = '<span style="opacity:.7;">'.$label.'</span>';
        }
        return $links;
    }
}

// === Update cache control ===
if (!function_exists('whm_update_force_refresh_on_check_again')) {
    function whm_update_force_refresh_on_check_again() {
        if (isset($_GET['force-check'])) {
            delete_site_transient('whm_update_meta_cache');
        }
    }
}

if (!function_exists('whm_handle_check_updates_now')) {
    function whm_handle_check_updates_now() {
        if (!current_user_can('update_plugins') && !current_user_can('manage_options')) {
            wp_die(__('Du hast keine Berechtigung, Plugins zu aktualisieren.', 'wp-health-monitor'));
        }
        check_admin_referer('whm_check_updates_now');
        delete_site_transient('whm_update_meta_cache');
        set_site_transient('update_plugins', null);
        wp_safe_redirect( admin_url('plugins.php?force-check=1') );
        exit;
    }
}

// === Self-Update Handler ===
if (!function_exists('whm_handle_self_update')) {
    function whm_handle_self_update() {
        // Permission: prefer update_plugins; allow manage_options as fallback to avoid generic "not allowed" page
        if ( ! current_user_can('update_plugins') && ! current_user_can('manage_options') ) {
            wp_safe_redirect( add_query_arg('whm_update_result', 'no-cap', admin_url('admin.php?page=wp-health-monitor')) );
            exit;
        }
        check_admin_referer('whm_self_update');

        delete_site_transient('whm_update_meta_cache');
        $meta = whm_get_update_metadata(true);
        $plugin_file = plugin_basename(__FILE__);

        if (empty($meta) || empty($meta['new_version']) || empty($meta['package'])) {
            set_site_transient('update_plugins', null);
            wp_safe_redirect( add_query_arg('whm_update_result', 'no-meta', admin_url('admin.php?page=wp-health-monitor')) );
            exit;
        }

        $installed_version = WHM_VERSION;
        $needs_update = version_compare($meta['new_version'], $installed_version, '>');

        if (!$needs_update && !empty($meta['build'])) {
            $needs_update = (defined('WHM_BUILD') && WHM_BUILD !== $meta['build']);
        }

        if (!$needs_update) {
            set_site_transient('update_plugins', null);
            wp_safe_redirect( add_query_arg('whm_update_result', 'no-update', admin_url('admin.php?page=wp-health-monitor')) );
            exit;
        }

        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        // Ensure transient contains the update info
        $transient = get_site_transient('update_plugins');
        if (!is_object($transient)) {
            $transient = (object) array('response' => array(), 'no_update' => array(), 'last_checked' => time());
        }
        $obj = new stdClass();
        $obj->slug        = 'wp-health-monitor';
        $obj->plugin      = $plugin_file;
        $obj->new_version = $meta['new_version'];
        $obj->url         = !empty($meta['url']) ? $meta['url'] : trailingslashit(WHM_UPDATE_BASE);
        $obj->package     = $meta['package'];
        $transient->response[$plugin_file] = $obj;
        set_site_transient('update_plugins', $transient);

        $skin = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result = $upgrader->upgrade($plugin_file);

        delete_site_transient('whm_update_meta_cache');
        set_site_transient('update_plugins', null);

        if (is_wp_error($result)) {
            $code = $result->get_error_code();
            wp_safe_redirect( add_query_arg(array('whm_update_result' => 'error', 'whm_update_error' => $code), admin_url('admin.php?page=wp-health-monitor')) );
            exit;
        }

        if ($result === true || $result) {
            wp_safe_redirect( add_query_arg('whm_update_result', 'success', admin_url('admin.php?page=wp-health-monitor')) );
            exit;
        } else {
            wp_safe_redirect( add_query_arg('whm_update_result', 'failed', admin_url('admin.php?page=wp-health-monitor')) );
            exit;
        }
    }
}

if (!function_exists('whm_self_update_admin_notices')) {
    function whm_self_update_admin_notices() {
        if (!isset($_GET['whm_update_result'])) return;
        $msg = '';
        $class = 'notice-info';
        switch (sanitize_text_field($_GET['whm_update_result'])) {
            case 'success':
                $msg = __('WP Health Monitor wurde erfolgreich aktualisiert.', 'wp-health-monitor');
                $class = 'notice-success';
                break;
            case 'no-update':
                $msg = __('Keine neuere Version gefunden.', 'wp-health-monitor');
                $class = 'notice-info';
                break;
            case 'no-meta':
                $msg = __('Update-Quelle nicht erreichbar oder fehlerhaft (kein Meta).', 'wp-health-monitor');
                $class = 'notice-warning';
                break;
            case 'failed':
                $msg = __('Aktualisierung fehlgeschlagen.', 'wp-health-monitor');
                $class = 'notice-error';
                break;
            case 'error':
                $err = isset($_GET['whm_update_error']) ? sanitize_text_field($_GET['whm_update_error']) : '';
                $msg = sprintf(__('Fehler bei der Aktualisierung: %s', 'wp-health-monitor'), $err);
                $class = 'notice-error';
                break;
            case 'no-cap':
                $msg = __('Dir fehlt die Berechtigung, dieses Plugin zu aktualisieren (update_plugins).', 'wp-health-monitor');
                $class = 'notice-error';
                break;
        }
        if ($msg) {
            echo '<div class="notice ' . esc_attr($class) . ' is-dismissible"><p>' . esc_html($msg) . '</p></div>';
        }
    }
}


/** ==================================================================
 *  WHM — GitHub Updater (admin-only, safe)
 *  ================================================================== */
if ( ! defined('WHM_GITHUB_OWNER') ) define('WHM_GITHUB_OWNER', 'eduardspadi66-dot');
if ( ! defined('WHM_GITHUB_REPO') )  define('WHM_GITHUB_REPO',  'WHM');
if ( ! defined('WHM_DEBUG') )        define('WHM_DEBUG', false);

if ( ! function_exists('whm_gh_safe_json') ) {
    function whm_gh_safe_json( $body ) {
        $data = json_decode( $body, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) { return null; }
        return is_array( $data ) ? $data : null;
    }
}
if ( ! function_exists('whm_gh_api_get') ) {
    function whm_gh_api_get( $url ) {
        $headers = array(
            'Accept'     => 'application/vnd.github+json',
            'User-Agent' => 'WP-Health-Monitor/' . ( defined('WHM_VERSION') ? WHM_VERSION : 'dev' ),
        );
        $args = array( 'timeout' => 15, 'sslverify' => true, 'headers' => $headers );
        if ( defined('WHM_GITHUB_TOKEN') && WHM_GITHUB_TOKEN ) {
            $args['headers']['Authorization'] = 'token ' . WHM_GITHUB_TOKEN;
        }
        $res = wp_remote_get( $url, $args );
        if ( is_wp_error( $res ) ) { return null; }
        if ( 200 !== wp_remote_retrieve_response_code( $res ) ) { return null; }
        return whm_gh_safe_json( wp_remote_retrieve_body( $res ) );
    }
}
if ( ! function_exists('whm_gh_get_meta') ) {
    function whm_gh_get_meta( $force = false ) {
        $key = 'whm_gh_meta';
        if ( ! $force ) {
            $cached = get_site_transient( $key );
            if ( $cached && is_array( $cached ) ) { return $cached; }
        }
        $owner = WHM_GITHUB_OWNER;
        $repo  = WHM_GITHUB_REPO;
        $base  = 'https://github.com/' . rawurlencode($owner) . '/' . rawurlencode($repo);

        $meta = null;
        $latest = whm_gh_api_get( 'https://api.github.com/repos/' . $owner . '/' . $repo . '/releases/latest' );
        if ( is_array( $latest ) && ! empty( $latest['tag_name'] ) ) {
            $tag = ltrim( $latest['tag_name'], 'vV' );
            $pkg = '';
            if ( ! empty( $latest['assets'] ) && is_array( $latest['assets'] ) ) {
                foreach ( $latest['assets'] as $a ) {
                    if ( ! empty( $a['name'] ) && preg_match( '/wp-health-monitor-[0-9]+\.[0-9]+\.[0-9]+\.zip$/', $a['name'] ) ) {
                        $pkg = $a['browser_download_url'];
                        break;
                    }
                }
            }
            if ( empty( $pkg ) ) { $pkg = $base . '/archive/refs/tags/' . $latest['tag_name'] . '.zip'; }
            $meta = array(
                'new_version' => $tag,
                'package'     => $pkg,
                'url'         => $base,
                'last_updated'=> ! empty( $latest['published_at'] ) ? $latest['published_at'] : '',
                'requires'    => '5.6',
                'tested'      => get_bloginfo('version'),
                'requires_php'=> '7.4',
                'sections'    => array( 'changelog' => ! empty( $latest['body'] ) ? $latest['body'] : '' ),
            );
        }
        if ( ! $meta ) {
            $tags = whm_gh_api_get( 'https://api.github.com/repos/' . $owner . '/' . $repo . '/tags' );
            if ( is_array( $tags ) && ! empty( $tags ) ) {
                $max = null;
                foreach ( $tags as $t ) {
                    if ( empty( $t['name'] ) ) { continue; }
                    $v = ltrim( $t['name'], 'vV' );
                    if ( $max === null || version_compare( $v, $max, '>' ) ) { $max = $v; }
                }
                if ( $max ) {
                    $meta = array(
                        'new_version' => $max,
                        'package'     => $base . '/archive/refs/tags/v' . $max . '.zip',
                        'url'         => $base,
                        'last_updated'=> '',
                        'requires'    => '5.6',
                        'tested'      => get_bloginfo('version'),
                        'requires_php'=> '7.4',
                        'sections'    => array( 'changelog' => '' ),
                    );
                }
            }
        }
        if ( ! $meta ) { return null; }
        set_site_transient( $key, $meta, HOUR_IN_SECONDS * 2 );
        return $meta;
    }
}

if ( ! function_exists('whm_gh_register_hooks') ) {
    function whm_gh_register_hooks() {
        add_filter( 'pre_set_site_transient_update_plugins', 'whm_gh_filter_update', 10, 1 );
        add_filter( 'plugins_api', 'whm_gh_plugins_api', 10, 3 );
        add_action( 'admin_post_whm_check_updates_now', 'whm_gh_handle_check_now' );
        add_action( 'admin_post_whm_self_update', 'whm_gh_handle_self_update' );
        add_action( 'admin_notices', 'whm_gh_admin_notices' );
    }
}

if ( is_admin() ) {
    if ( ! function_exists('whm_gh_filter_update') ) {
        function whm_gh_filter_update( $transient ) {
            if ( empty( $transient ) || ! is_object( $transient ) ) { return $transient; }
            $meta = whm_gh_get_meta( false );
            if ( ! $meta || empty( $meta['new_version'] ) ) { return $transient; }
            if ( version_compare( $meta['new_version'], WHM_VERSION, '>' ) ) {
                $plugin_file = plugin_basename( __FILE__ );
                $obj = (object) array(
                    'slug'        => 'wp-health-monitor',
                    'plugin'      => $plugin_file,
                    'new_version' => $meta['new_version'],
                    'url'         => $meta['url'],
                    'package'     => $meta['package'],
                );
                $transient->response[ $plugin_file ] = $obj;
            }
            return $transient;
        }
    }
    if ( ! function_exists('whm_gh_plugins_api') ) {
        function whm_gh_plugins_api( $res, $action, $args ) {
            if ( $action !== 'plugin_information' ) { return $res; }
            if ( empty( $args->slug ) || $args->slug !== 'wp-health-monitor' ) { return $res; }
            $meta = whm_gh_get_meta( false );
            if ( ! $meta ) { return $res; }
            $info = new stdClass();
            $info->name          = 'WP Health Monitor';
            $info->slug          = 'wp-health-monitor';
            $info->version       = $meta['new_version'];
            $info->author        = '<a href="https://webdivision.io" target="_blank" rel="noreferrer">ProjectPartner Kleeschulte GmbH</a>';
            $info->homepage      = $meta['url'];
            $info->download_link = $meta['package'];
            $info->requires      = $meta['requires'];
            $info->tested        = $meta['tested'];
            $info->requires_php  = $meta['requires_php'];
            $info->last_updated  = $meta['last_updated'];
            $info->sections      = $meta['sections'];
            return $info;
        }
    }
    if ( ! function_exists('whm_gh_handle_check_now') ) {
        function whm_gh_handle_check_now() {
            if ( ! current_user_can('update_plugins') && ! current_user_can('manage_options') ) { wp_die('Keine Berechtigung.'); }
            check_admin_referer( 'whm_check_updates_now' );
            delete_site_transient( 'whm_gh_meta' );
            set_site_transient( 'update_plugins', null );
            wp_safe_redirect( admin_url( 'plugins.php?force-check=1' ) );
            exit;
        }
    }
    if ( ! function_exists('whm_gh_handle_self_update') ) {
        function whm_gh_handle_self_update() {
            if ( ! current_user_can('update_plugins') && ! current_user_can('manage_options') ) {
                wp_safe_redirect( add_query_arg( 'whm_update_result', 'no-cap', admin_url( 'admin.php?page=wp-health-monitor' ) ) );
                exit;
            }
            check_admin_referer( 'whm_self_update' );

            delete_site_transient( 'whm_gh_meta' );
            $meta = whm_gh_get_meta( true );
            if ( ! $meta || empty( $meta['new_version'] ) || empty( $meta['package'] ) ) {
                set_site_transient( 'update_plugins', null );
                wp_safe_redirect( add_query_arg( 'whm_update_result', 'no-meta', admin_url( 'admin.php?page=wp-health-monitor' ) ) );
                exit;
            }
            if ( ! version_compare( $meta['new_version'], WHM_VERSION, '>' ) ) {
                set_site_transient( 'update_plugins', null );
                wp_safe_redirect( add_query_arg( 'whm_update_result', 'no-update', admin_url( 'admin.php?page=wp-health-monitor' ) ) );
                exit;
            }

            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
            require_once ABSPATH . 'wp-admin/includes/plugin.php';

            $plugin_file = plugin_basename( __FILE__ );
            $transient = get_site_transient( 'update_plugins' );
            if ( ! is_object( $transient ) ) {
                $transient = (object) array( 'response' => array(), 'no_update' => array(), 'last_checked' => time() );
            }
            $obj = (object) array(
                'slug'        => 'wp-health-monitor',
                'plugin'      => $plugin_file,
                'new_version' => $meta['new_version'],
                'url'         => $meta['url'],
                'package'     => $meta['package'],
            );
            $transient->response[ $plugin_file ] = $obj;
            set_site_transient( 'update_plugins', $transient );

            $skin = new Automatic_Upgrader_Skin();
            $upgrader = new Plugin_Upgrader( $skin );
            $result = $upgrader->upgrade( $plugin_file );

            delete_site_transient( 'whm_gh_meta' );
            set_site_transient( 'update_plugins', null );

            if ( is_wp_error( $result ) ) {
                $code = $result->get_error_code();
                wp_safe_redirect( add_query_arg( array( 'whm_update_result' => 'error', 'whm_update_error' => $code ), admin_url( 'admin.php?page=wp-health-monitor' ) ) );
                exit;
            }
            wp_safe_redirect( add_query_arg( 'whm_update_result', ( $result ? 'success' : 'failed' ), admin_url( 'admin.php?page=wp-health-monitor' ) ) );
            exit;
        }
    }
    if ( ! function_exists('whm_gh_admin_notices') ) {
        function whm_gh_admin_notices() {
            if ( ! isset( $_GET['whm_update_result'] ) ) { return; }
            $map = array(
                'success'   => array( 'notice-success', 'WP Health Monitor wurde erfolgreich aktualisiert.' ),
                'no-update' => array( 'notice-info',    'Keine neuere Version gefunden.' ),
                'no-meta'   => array( 'notice-warning', 'Update-Quelle (GitHub) nicht erreichbar oder fehlerhaft.' ),
                'failed'    => array( 'notice-error',   'Aktualisierung fehlgeschlagen.' ),
                'error'     => array( 'notice-error',   'Fehler bei der Aktualisierung.' ),
                'no-cap'    => array( 'notice-error',   'Dir fehlt die Berechtigung, dieses Plugin zu aktualisieren.' ),
            );
            $k = sanitize_text_field( $_GET['whm_update_result'] );
            if ( ! empty( $map[ $k ] ) ) {
                echo '<div class="notice ' . esc_attr( $map[$k][0] ) . ' is-dismissible"><p>' . esc_html( $map[$k][1] ) . '</p></div>';
            }
        }
    }

    // Register hooks after functions exist
    add_action( 'admin_init', 'whm_gh_register_hooks' );

    // Backward-compat: if old buttons call legacy handlers, route them to GH handlers
    if ( ! function_exists('whm_handle_check_updates_now') ) {
        function whm_handle_check_updates_now() { return whm_gh_handle_check_now(); }
    }
    if ( ! function_exists('whm_handle_self_update') ) {
        function whm_handle_self_update() { return whm_gh_handle_self_update(); }
    }
}


/** ==================================================================
 *  WHM — JSON Status Output (includes "Letztes Update durchgeführt von")
 *  ================================================================== */
if ( ! function_exists('whm_status_data') ) {
    function whm_status_data() {
        $data = array(
            'version'             => defined('WHM_VERSION') ? WHM_VERSION : '',
            'build'               => defined('WHM_BUILD') ? WHM_BUILD : '',
            'last_updated_by'     => get_option( WHM_OPTION_LAST_UPDATED_BY, '' ),
            'last_updated_date'   => get_option( WHM_OPTION_LAST_UPDATED_DATE, '' ),
            'notes'               => get_option( WHM_OPTION_NOTES, '' ),
        );
        /**
         * Filter allows extending the JSON payload.
         * @param array $data
         */
        return apply_filters('whm_status_data', $data);
    }
}

if ( ! function_exists('whm_register_status_rest_route') ) {
    function whm_register_status_rest_route() {
        register_rest_route( 'whm/v1', '/status', array(
            'methods'  => 'GET',
            'callback' => function( $request ) {
                return rest_ensure_response( whm_status_data() );
            },
            'permission_callback' => '__return_true', // public; change to capability check if needed
        ) );
    }
    add_action( 'rest_api_init', 'whm_register_status_rest_route' );
}

if ( ! function_exists('whm_status_query_endpoint') ) {
    function whm_status_query_endpoint() {
        if ( isset($_GET['whm_json']) && $_GET['whm_json'] == '1' ) {
            // Public JSON output via query param
            nocache_headers();
            header('Content-Type: application/json; charset=' . get_bloginfo('charset'));
            echo wp_json_encode( whm_status_data() );
            exit;
        }
    }
    add_action( 'template_redirect', 'whm_status_query_endpoint' );
}


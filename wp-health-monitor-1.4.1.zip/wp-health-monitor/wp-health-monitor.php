<?php
/*
Plugin Name: WP Health Monitor
Description: Monitoring für Core, Plugins, Themes
Version: 1.4.1
Author: ProjectPartner Kleeschulte GmbH
*/

if ( ! defined('ABSPATH') ) { exit; }

// ============================================================================
// Constants
// ============================================================================
if ( ! defined('WHM_VERSION') ) define('WHM_VERSION', '1.4.1');
if ( ! defined('WHM_BUILD') )   define('WHM_BUILD',  date('Y-m-d'));

if ( ! defined('WHM_OPTION_TIME1') )              define('WHM_OPTION_TIME1', 'whm_time1');
if ( ! defined('WHM_OPTION_TIME2') )              define('WHM_OPTION_TIME2', 'whm_time2');
if ( ! defined('WHM_OPTION_LAST_UPDATED_BY') )    define('WHM_OPTION_LAST_UPDATED_BY', 'whm_last_updated_by');
if ( ! defined('WHM_OPTION_LAST_UPDATED_DATE') )  define('WHM_OPTION_LAST_UPDATED_DATE', 'whm_last_updated_date');
if ( ! defined('WHM_OPTION_NOTES') )              define('WHM_OPTION_NOTES', 'whm_notes');

// GitHub source defaults
if ( ! defined('WHM_GITHUB_OWNER') ) define('WHM_GITHUB_OWNER', 'eduardspadi66-dot');
if ( ! defined('WHM_GITHUB_REPO') )  define('WHM_GITHUB_REPO',  'WHM');
if ( ! defined('WHM_DEBUG') )        define('WHM_DEBUG', false);

// ============================================================================
// Helpers
// ============================================================================
if ( ! function_exists('whm_safe_json_decode') ) {
    function whm_safe_json_decode( $body ) {
        $data = json_decode( $body, true );
        if ( json_last_error() !== JSON_ERROR_NONE ) { return null; }
        return is_array($data) ? $data : null;
    }
}
if ( ! function_exists('whm_debug_log') ) {
    function whm_debug_log( $msg ) {
        if ( defined('WHM_DEBUG') && WHM_DEBUG ) {
            error_log('[WHM] ' . ( is_string($msg) ? $msg : print_r($msg, true) ));
        }
    }
}

// ============================================================================
// Admin Page
// ============================================================================
add_action( 'admin_menu', function() {
    add_menu_page(
        'WP Health Monitor',
        'WP Health Monitor',
        'manage_options',
        'wp-health-monitor',
        'whm_admin_page_render',
        'dashicons-heart',
        66
    );
});

if ( ! function_exists('whm_admin_page_render') ) {
    function whm_admin_page_render() {
        if ( ! current_user_can('manage_options') ) {
            wp_safe_redirect( admin_url() );
            exit;
        }
        $t1 = get_option(WHM_OPTION_TIME1, '03:00');
        $t2 = get_option(WHM_OPTION_TIME2, '18:00');
        $by = get_option(WHM_OPTION_LAST_UPDATED_BY, '');
        $dt = get_option(WHM_OPTION_LAST_UPDATED_DATE, '');
        $nt = get_option(WHM_OPTION_NOTES, '');
        ?>
        <div class="wrap">
            <h1>WP Health Monitor</h1>
            <p><em>Version:</em> <?php echo esc_html(WHM_VERSION); ?> · <em>Build:</em> <?php echo esc_html(WHM_BUILD); ?></p>

            <?php if ( ! empty($by) || ! empty($dt) ) : ?>
                <p>Zuletzt gewartet<?php echo $by ? ' von <strong>'.esc_html($by).'</strong>' : ''; ?><?php echo $dt ? ' am <strong>'.esc_html($dt).'</strong>' : ''; ?>.</p>
            <?php endif; ?>

            <?php if ( isset($_GET['whm_update_result']) ) : ?>
                <?php
                $map = array(
                    'success'   => array( 'notice-success', 'WP Health Monitor wurde erfolgreich aktualisiert.' ),
                    'no-update' => array( 'notice-info',    'Keine neuere Version gefunden.' ),
                    'no-meta'   => array( 'notice-warning', 'Update-Quelle (GitHub) nicht erreichbar oder fehlerhaft.' ),
                    'failed'    => array( 'notice-error',   'Aktualisierung fehlgeschlagen.' ),
                    'error'     => array( 'notice-error',   'Fehler bei der Aktualisierung.' ),
                    'no-cap'    => array( 'notice-error',   'Dir fehlt die Berechtigung, dieses Plugin zu aktualisieren.' ),
                    'bad-nonce' => array( 'notice-error',   'Sicherheits-Token (Nonce) ungültig oder abgelaufen. Bitte Seite neu laden.' ),
                );
                $k = sanitize_text_field($_GET['whm_update_result']);
                if ( ! empty($map[$k]) ) {
                    echo '<div class="notice ' . esc_attr( $map[$k][0] ) . ' is-dismissible"><p>' . esc_html( $map[$k][1] ) . '</p></div>';
                }
                ?>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
                <?php wp_nonce_field( 'whm_save_settings', 'whm_nonce' ); ?>
                <input type="hidden" name="action" value="whm_save_settings" />
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><label for="whm_time1">Scan-Zeit #1</label></th>
                            <td><input type="time" id="whm_time1" name="whm_time1" value="<?php echo esc_attr($t1); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="whm_time2">Scan-Zeit #2</label></th>
                            <td><input type="time" id="whm_time2" name="whm_time2" value="<?php echo esc_attr($t2); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row">Letztes Update durchgeführt von</th>
                            <td><input type="text" name="whm_last_updated_by" class="regular-text" value="<?php echo esc_attr($by); ?>" placeholder="Name des Mitarbeiters"></td>
                        </tr>
                        <tr>
                            <th scope="row">Datum der letzten Wartung</th>
                            <td><input type="date" name="whm_last_updated_date" value="<?php echo esc_attr($dt); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row">Bemerkungen</th>
                            <td><textarea name="whm_notes" rows="4" class="large-text" placeholder="Interne Notizen…"><?php echo esc_textarea($nt); ?></textarea></td>
                        </tr>
                        <tr>
                            <th scope="row">Updates</th>
                            <td>
                                <a class="button" href="<?php echo wp_nonce_url( admin_url('admin-post.php?action=whm_check_updates_now'), 'whm_check_updates_now' ); ?>">Update jetzt prüfen</a>
                                <a class="button button-primary" href="<?php echo wp_nonce_url( admin_url('admin-post.php?action=whm_self_update'), 'whm_self_update' ); ?>">Jetzt aktualisieren</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <p class="submit">
                    <button type="submit" class="button button-secondary">Einstellungen speichern</button>
                </p>
            </form>
        </div>
        <?php
    }
}

// Save settings
add_action('admin_post_whm_save_settings', function() {
    if ( ! current_user_can('manage_options') ) {
        wp_safe_redirect( admin_url('admin.php?page=wp-health-monitor&whm_update_result=no-cap') );
        exit;
    }
    if ( ! isset($_POST['whm_nonce']) || ! wp_verify_nonce($_POST['whm_nonce'], 'whm_save_settings') ) {
        wp_safe_redirect( admin_url('admin.php?page=wp-health-monitor&whm_update_result=bad-nonce') );
        exit;
    }
    $t1 = isset($_POST['whm_time1']) ? sanitize_text_field($_POST['whm_time1']) : '03:00';
    $t2 = isset($_POST['whm_time2']) ? sanitize_text_field($_POST['whm_time2']) : '18:00';
    $by = isset($_POST['whm_last_updated_by']) ? sanitize_text_field($_POST['whm_last_updated_by']) : '';
    $dt = isset($_POST['whm_last_updated_date']) ? sanitize_text_field($_POST['whm_last_updated_date']) : '';
    $nt = isset($_POST['whm_notes']) ? sanitize_textarea_field($_POST['whm_notes']) : '';

    update_option(WHM_OPTION_TIME1, $t1, false);
    update_option(WHM_OPTION_TIME2, $t2, false);
    update_option(WHM_OPTION_LAST_UPDATED_BY, $by, false);
    update_option(WHM_OPTION_LAST_UPDATED_DATE, $dt, false);
    update_option(WHM_OPTION_NOTES, $nt, false);

    wp_safe_redirect( admin_url('admin.php?page=wp-health-monitor') );
    exit;
});

// Show version/build in plugin row
add_filter('plugin_row_meta', function($links, $file){
    if ( $file === plugin_basename(__FILE__) ) {
        $label = 'v'.WHM_VERSION;
        if ( defined('WHM_BUILD') && WHM_BUILD ) { $label .= ' · Build '.WHM_BUILD; }
        $links[] = '<span style="opacity:.7;">'.$label.'</span>';
    }
    return $links;
}, 10, 2);

// ============================================================================
// Public JSON status
// ============================================================================
if ( ! function_exists('whm_status_data') ) {
    function whm_status_data() {
        $data = array(
            'version'           => WHM_VERSION,
            'build'             => WHM_BUILD,
            'last_updated_by'   => get_option( WHM_OPTION_LAST_UPDATED_BY, '' ),
            'last_updated_date' => get_option( WHM_OPTION_LAST_UPDATED_DATE, '' ),
            'notes'             => get_option( WHM_OPTION_NOTES, '' ),
            'site'              => home_url(),
        );
        return apply_filters('whm_status_data', $data);
    }
}
add_action('rest_api_init', function(){
    register_rest_route( 'whm/v1', '/status', array(
        'methods'  => 'GET',
        'callback' => function(){ return rest_ensure_response( whm_status_data() ); },
        'permission_callback' => '__return_true',
    ));
});
add_action('template_redirect', function(){
    if ( isset($_GET['whm_json']) && $_GET['whm_json'] == '1' ) {
        nocache_headers();
        header('Content-Type: application/json; charset=' . get_bloginfo('charset'));
        echo wp_json_encode( whm_status_data() );
        exit;
    }
});

// ============================================================================
// GitHub Updater (admin-only)
// ============================================================================
if ( is_admin() ) {

    if ( ! function_exists('whm_api_get') ) {
        function whm_api_get( $url ) {
            $headers = array(
                'Accept'     => 'application/vnd.github+json',
                'User-Agent' => 'WP-Health-Monitor/'.WHM_VERSION,
            );
            $args = array( 'timeout' => 15, 'sslverify' => true, 'headers' => $headers );
            if ( defined('WHM_GITHUB_TOKEN') && WHM_GITHUB_TOKEN ) {
                $args['headers']['Authorization'] = 'token ' . WHM_GITHUB_TOKEN;
            }
            $res = wp_remote_get( $url, $args );
            if ( is_wp_error($res) ) { return null; }
            if ( 200 !== wp_remote_retrieve_response_code($res) ) { return null; }
            return whm_safe_json_decode( wp_remote_retrieve_body($res) );
        }
    }

    if ( ! function_exists('whm_get_meta') ) {
        function whm_get_meta( $force = false ) {
            $key = 'whm_gh_meta';
            if ( ! $force ) {
                $cached = get_site_transient($key);
                if ( $cached && is_array($cached) ) return $cached;
            }
            $owner = WHM_GITHUB_OWNER;
            $repo  = WHM_GITHUB_REPO;
            $base  = 'https://github.com/' . rawurlencode($owner) . '/' . rawurlencode($repo);

            $meta = null;
            $latest = whm_api_get('https://api.github.com/repos/'.$owner.'/'.$repo.'/releases/latest');
            if ( is_array($latest) && ! empty($latest['tag_name']) ) {
                $tag = ltrim( $latest['tag_name'], 'vV' );
                $pkg = '';
                if ( ! empty($latest['assets']) && is_array($latest['assets']) ) {
                    foreach ( $latest['assets'] as $a ) {
                        if ( ! empty($a['name']) && preg_match('/wp-health-monitor-[0-9]+\.[0-9]+\.[0-9]+\.zip$/', $a['name']) ) {
                            $pkg = $a['browser_download_url'];
                            break;
                        }
                    }
                }
                if ( empty($pkg) ) { $pkg = $base.'/archive/refs/tags/'.$latest['tag_name'].'.zip'; }
                $meta = array(
                    'new_version' => $tag,
                    'package'     => $pkg,
                    'url'         => $base,
                    'last_updated'=> ! empty($latest['published_at']) ? $latest['published_at'] : '',
                    'requires'    => '5.6',
                    'tested'      => get_bloginfo('version'),
                    'requires_php'=> '7.4',
                    'sections'    => array( 'changelog' => ! empty($latest['body']) ? $latest['body'] : '' ),
                );
            }

            if ( ! $meta ) {
                $tags = whm_api_get('https://api.github.com/repos/'.$owner.'/'.$repo.'/tags');
                if ( is_array($tags) && ! empty($tags) ) {
                    $max = null;
                    foreach ( $tags as $t ) {
                        if ( empty($t['name']) ) continue;
                        $v = ltrim($t['name'], 'vV');
                        if ( $max === null || version_compare($v, $max, '>') ) $max = $v;
                    }
                    if ( $max ) {
                        $meta = array(
                            'new_version' => $max,
                            'package'     => $base.'/archive/refs/tags/v'.$max.'.zip',
                            'url'         => $base,
                            'last_updated'=> '',
                            'requires'    => '5.6',
                            'tested'      => get_bloginfo('version'),
                            'requires_php'=> '7.4',
                            'sections'    => array( 'changelog' => '' ),
                        );
                    }
                }
            }

            if ( ! $meta ) return null;
            set_site_transient( $key, $meta, HOUR_IN_SECONDS * 2 );
            return $meta;
        }
    }

    if ( ! function_exists('whm_filter_update') ) {
        function whm_filter_update( $transient ) {
            if ( empty($transient) || ! is_object($transient) ) return $transient;
            $meta = whm_get_meta(false);
            if ( ! $meta || empty($meta['new_version']) ) return $transient;
            if ( version_compare($meta['new_version'], WHM_VERSION, '>') ) {
                $plugin_file = plugin_basename(__FILE__);
                $obj = (object) array(
                    'slug'        => 'wp-health-monitor',
                    'plugin'      => $plugin_file,
                    'new_version' => $meta['new_version'],
                    'url'         => $meta['url'],
                    'package'     => $meta['package'],
                );
                $transient->response[$plugin_file] = $obj;
            }
            return $transient;
        }
        add_filter('pre_set_site_transient_update_plugins', 'whm_filter_update', 10, 1);
    }

    if ( ! function_exists('whm_plugins_api') ) {
        function whm_plugins_api( $res, $action, $args ) {
            if ( $action !== 'plugin_information' ) return $res;
            if ( empty($args->slug) || $args->slug !== 'wp-health-monitor' ) return $res;
            $meta = whm_get_meta(false);
            if ( ! $meta ) return $res;
            $info = new stdClass();
            $info->name          = 'WP Health Monitor';
            $info->slug          = 'wp-health-monitor';
            $info->version       = $meta['new_version'];
            $info->author        = '<a href="https://webdivision.io" target="_blank" rel="noreferrer">ProjectPartner Kleeschulte GmbH</a>';
            $info->homepage      = $meta['url'];
            $info->download_link = $meta['package'];
            $info->requires      = $meta['requires'];
            $info->tested        = $meta['tested'];
            $info->requires_php  = $meta['requires_php'];
            $info->last_updated  = $meta['last_updated'];
            $info->sections      = $meta['sections'];
            return $info;
        }
        add_filter('plugins_api', 'whm_plugins_api', 10, 3);
    }

    // Manual check + self-update (redirects with notices, never echo)
    if ( ! function_exists('whm_handle_check_updates_now') ) {
        function whm_handle_check_updates_now() {
            $redirect = admin_url('plugins.php?force-check=1');
            if ( ! current_user_can('update_plugins') && ! current_user_can('manage_options') ) {
                wp_safe_redirect( admin_url('admin.php?page=wp-health-monitor&whm_update_result=no-cap') );
                exit;
            }
            if ( ! isset($_REQUEST['_wpnonce']) || ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'whm_check_updates_now' ) ) {
                wp_safe_redirect( admin_url('admin.php?page=wp-health-monitor&whm_update_result=bad-nonce') );
                exit;
            }
            delete_site_transient('whm_gh_meta');
            set_site_transient('update_plugins', null);
            wp_safe_redirect( $redirect );
            exit;
        }
        add_action('admin_post_whm_check_updates_now', 'whm_handle_check_updates_now');
        add_action('admin_post_nopriv_whm_check_updates_now', function(){ auth_redirect(); });
    }

    if ( ! function_exists('whm_handle_self_update') ) {
        function whm_handle_self_update() {
            $redirect = admin_url('admin.php?page=wp-health-monitor');
            if ( ! current_user_can('update_plugins') && ! current_user_can('manage_options') ) {
                wp_safe_redirect( add_query_arg('whm_update_result', 'no-cap', $redirect) );
                exit;
            }
            if ( ! isset($_REQUEST['_wpnonce']) || ! wp_verify_nonce( $_REQUEST['_wpnonce'], 'whm_self_update' ) ) {
                wp_safe_redirect( add_query_arg('whm_update_result', 'bad-nonce', $redirect) );
                exit;
            }

            delete_site_transient('whm_gh_meta');
            $meta = whm_get_meta(true);
            if ( ! $meta || empty($meta['new_version']) || empty($meta['package']) ) {
                set_site_transient('update_plugins', null);
                wp_safe_redirect( add_query_arg('whm_update_result', 'no-meta', $redirect) );
                exit;
            }
            if ( ! version_compare($meta['new_version'], WHM_VERSION, '>') ) {
                set_site_transient('update_plugins', null);
                wp_safe_redirect( add_query_arg('whm_update_result', 'no-update', $redirect) );
                exit;
            }

            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
            require_once ABSPATH . 'wp-admin/includes/plugin.php';

            $plugin_file = plugin_basename(__FILE__);
            $transient = get_site_transient('update_plugins');
            if ( ! is_object($transient) ) {
                $transient = (object) array( 'response' => array(), 'no_update' => array(), 'last_checked' => time() );
            }
            $obj = (object) array(
                'slug'        => 'wp-health-monitor',
                'plugin'      => $plugin_file,
                'new_version' => $meta['new_version'],
                'url'         => $meta['url'],
                'package'     => $meta['package'],
            );
            $transient->response[$plugin_file] = $obj;
            set_site_transient('update_plugins', $transient);

            $skin = new Automatic_Upgrader_Skin();
            $upgrader = new Plugin_Upgrader( $skin );
            $result = $upgrader->upgrade( $plugin_file );

            delete_site_transient('whm_gh_meta');
            set_site_transient('update_plugins', null);

            if ( is_wp_error($result) ) {
                $code = $result->get_error_code();
                wp_safe_redirect( add_query_arg( array('whm_update_result'=>'error','whm_update_error'=>$code), $redirect ) );
                exit;
            }
            wp_safe_redirect( add_query_arg( 'whm_update_result', ($result ? 'success' : 'failed'), $redirect ) );
            exit;
        }
        add_action('admin_post_whm_self_update', 'whm_handle_self_update');
        add_action('admin_post_nopriv_whm_self_update', function(){ auth_redirect(); });
    }

    // Legacy shims for safety
    if ( ! function_exists('whm_get_update_metadata') ) {
        function whm_get_update_metadata( $force = false ) { return whm_get_meta( $force ); }
    }
    if ( ! function_exists('whm_check_for_plugin_update') ) {
        function whm_check_for_plugin_update( $t ) { return whm_filter_update( $t ); }
    }
    if ( ! function_exists('whm_plugins_api_handler') ) {
        function whm_plugins_api_handler( $res, $action, $args ) { return whm_plugins_api( $res, $action, $args ); }
    }
}
